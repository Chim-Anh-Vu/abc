import requests
from os import system, name
from getpass import getpass
import os, sys
from schnorr import create_key, verify_docs, sign_docs, verify
from Crypto.Util.Padding import unpad
from Crypto.Cipher import AES
from ecc import PrivateKey, S256Field, S256Point
import re
from hashlib import sha224

S_URL = 'http://127.0.0.1:8080/savefile'


USERNAME = ''
PASSWORD = ''

def upload(username:str, password:str, filename:str):
    n_filename = filename.replace('/', '|').replace('\\', '|').split('|')[-1]
    cookies = {'filename':n_filename, 'username':username, 'pass':password}
    try:
        with open(filename, 'rb') as f:
            f_post = {'file': f}
            r = requests.post(S_URL+'/', cookies=cookies, files=f_post)
            if r.status_code == 200:
                print('Upload file succeed')
                return 0
            elif r.status_code == 403:
                print('Login failed')
                return 1
            elif r.status_code == 500:
                print('Server error, cannot upload file')
                return 2
            elif r.status_code == 405:
                print('File is not signed yet')
                return 3
            elif r.status_code == 406:
                print('Please check it again, file %s is already exist!' %filename)
                return 4
            else:
                print('Errors')
                return 5
    except Exception as e:
        print(e)
        return 5

def download_filename(username:str, password:str, filename:str):
    cookies = {'username':username, 'pass':password}
    url = S_URL + '?action=downloadfile&filename='+filename
    r = requests.get(url, cookies=cookies)
    if r.status_code == 200:
        if os.path.isfile('Download'):
            os.remove('Download')
        if not os.path.isdir('Download'):
            os.mkdir('Download')
        abs_path = os.path.join('Download', filename)
        with open(abs_path, 'wb') as f:
            f.write(r.content)
        print("Donwload success")
        print('File is saved in %s' % abs_path)
        return 0
    elif r.status_code == 403:
        print('Login failed')
        return 1
    elif r.status_code == 404:
        print('Not found file')
        return 2
    elif r.status_code == 500:
        print('Server errors')
        return 3
    else:
        print('Error download file')
        return 4

def download_hash_file(username:str, password:str, hash_val:str):
    cookies = {'username':username, 'pass':password}
    url = S_URL + '?action=gethashfile&fh=' + hash_val
    r = requests.get(url, cookies=cookies)
    if r.status_code == 200:

        filename = r.cookies['filename']
        abs_path = os.path.join('Download', filename)
        with open(abs_path, 'wb') as f:
            f.write(r.content)
        print('Download success')
        return 0
    elif r.status_code == 403:
        print('Login failed')
        return 1
    elif r.status_code == 404:
        print('Not found file')
        return 2
    elif r.status_code == 500:
        print('Server errors')
        return 3
    else:
        print('Errors')
        return 4

def login(username:str, password:str):
    cookies = {'username': username, 'pass':password}
    r = requests.get(S_URL+'/login/', cookies=cookies)
    if r.status_code == 200:
        print('Login success')
        return True
    elif r.status_code == 403:
        print('Login information is incorrect')
        return False
    else:
        print('Errors')
        return False

def change_pass(username:str, oldpass:str, newpass:str):
    cookies = {'username': username, 'pass':oldpass}
    url = S_URL + '?action=changepass&newpass=' + newpass
    r = requests.get(url, cookies=cookies)
    if r.status_code == 200:
        print('Password has changed')
        return 0
    elif r.status_code == 403:
        print('Login failed')
        return 1
    elif r.status_code == 500:
        print('Server Errors')
        return 2
    else:
        print('Errors')
        return 3

def get_list_file(username:str, pwd:str):
    cookies = {'username':username, 'pass':pwd}
    r = requests.get(S_URL+'?action=getlist', cookies=cookies)
    if r.status_code == 200:
        ret = r.json()
        data = '\n'.join(ret['list'])
        print(data)
    else:
        print(username, pwd)
        print(r.status_code)
        print('Error')

def get_sharable_url(username:str, pwd:str, filename:str):
    cookies = {'username':username, 'pass':pwd}
    r = requests.get(S_URL+'?action=getsharableurl&filename='+filename, cookies=cookies)
    if r.status_code == 200:
        data = r.json()
        print(data['Shared URL'])
    elif r.status_code == 404:
        print('Not found')
    else:
        print('Errors')

def gen_key():
    if not os.path.isdir('Keys'):
        os.remove('Keys')
        os.mkdir('Keys')
    if os.path.isfile(os.path.join('Keys', 'Private.key')):
        print('Key is already existed')
        choice = input('Are you sure to create new key? (y/N):')
        if choice in ['y', 'Y']:
            create_key()
        else:
            print('User previous key')
            pass
    #TODO: 

def sign_file(username:str, filename:str):
    if not os.path.isdir('Signed Files'):
        os.remove('Signed Files')
        os.mkdir('Signed Files')
    if os.path.isfile(os.path.join('Signed Files', filename+'_signed')):
        print('File %s is already signed' %filename)
        return
    else:
        sign_docs(username,filename)
        return
    #TODO: sig
    pass

def check_file_signed(username:str, filename_signed:str):
    try:
        with open(filename_signed, 'rb') as f:
            file_data = f.read()
            end_bytes = file_data[-464:]
            file_pad = file_data[:-464]
            end_bytes = unpad(end_bytes, AES.block_size)
            file_unpad = unpad(file_pad, AES.block_size)
            [x, y, a, b, s, px, py, pa, pb, chk] = end_bytes.decode('utf8').split('|')
            R = S256Point(S256Field(int(x)), S256Field(int(y)), S256Field(int(a)), S256Field(int(b)))
            public_point = S256Point(S256Field(int(px)), S256Field(int(py)), S256Field(int(pa)), S256Field(int(pb)))
            if verify(R, s, file_unpad, public_point):
                get_user_infor(chk)
                return True
            else:
                print('Cannot verify')
                return False
    except Exception as e:
        print(e)
        return False

def get_user_infor(hash_file:str):
    r = requests.get(S_URL+'?action=getuserinfor&hash='+hash_file)
    if r.status_code == 200:
        ret = r.json()
        owner = ret['owner']
        mail = ret['mail']
        print('\nVerified, \nFile belong to user: %s \nEmail: %s'%(owner, mail))
    else:
        print('Cannot verify file')

def get_hash(filename:str):
    try:
        with open(filename, 'rb') as f:
            all_file = f.read()
            end_bytes = unpad(all_file[-464:], AES.block_size)
            chk = end_bytes.decode('utf8').split('|')[-1]
            return chk
    except Exception as e:
        print(e)
        return None
            
def to_original(filename:str):
    if os.path.isfile('Original'):
        os.remove('Original')
        os.mkdir('Original')
    elif not os.path.isdir('Original'):
        os.mkdir('Original')
    try:
        with open(filename, 'rb') as f:
            data = unpad(f.read()[:-464], AES.block_size)
            if filename.endswith('_signed'):
                new_filename = filename.replace('_signed', '').replace('/', '|').replace('\\', '|').split('|')[-1]
            else:
                new_filename = filename.replace('\\', '|').replace('/', '|').split('|')[-1]
            with open(os.path.join('Original', new_filename), 'wb') as f1:
                f1.write(data)
            print('Success')
            print('Please check %s' %os.path.join('Original', new_filename))
    except Exception as e:
        print(e)


def print_menu():
    print('****************************************')
    print('Select:')
    print('1: Upload file')
    print('2: Download file')
    print('3: Get list of files')
    print('4: Get sharable URL of a file')
    print('5: Change password')
    print('6: Genarate key')
    print('7: Sign a file')
    print('8: Check file signed')
    print('9: Convert to original file')
    print('10: Exit')
    print('****************************************')

def clear_scr():
    if name == 'nt':
        system('cls')
    else:
        system('clear')

def before_main():
    print('Login')
    USERNAME = input('Username: ')
    PASSWORD = getpass('Password: ')
    m = sha224()
    m.update(bytes(PASSWORD, encoding='utf8'))
    PASSWORD = m.hexdigest()
    if login(USERNAME, PASSWORD):
        main(USERNAME, PASSWORD)
    else:
        print('Login failed\nExit')
    

def main(username:str, pwd:str):
    while True:
        clear_scr()
        print_menu()
        selector = input()
        if selector == '1':
            clear_scr()
            filename = input('Filename: ')
            if os.path.isfile(filename):
                upload(username, pwd, filename)
            else:
                print(filename,'is not file')
            input('\nPress any key to continue')
        elif selector == '2':
            clear_scr()
            choice = input('Input Filename or sharable URL: ')
            if choice.startswith('http://'):
                fh  = choice.rstrip('/').split('=')[-1]
                download_hash_file(username, pwd, fh)
            else:
                download_filename(username, pwd, choice)
            input('\nPress any key to continue')
        elif selector == '3':
            clear_scr()
            get_list_file(username, pwd)
            input('\nPress any key to continue')
        elif selector == '4':
            clear_scr()
            filename = input('Filename? ')
            get_sharable_url(username, pwd, filename)
            input('\nPress any key to continue')
        elif selector == '5':
            clear_scr()
            newpass = getpass('Enter new password')
            newpass_again = getpass('Verify new password')
            if newpass == newpass_again:
                change_pass(username, pwd, newpass_again)
            input('\nPress any key to continue')
        elif selector == '6':
            clear_scr()
            gen_key()
            input('\nPress any key to continue')
        elif selector == '7':
            clear_scr()
            filename = input('Filename? ')
            sign_file(username, filename)
            input('\nPress any key to continue')
        elif selector == '8':
            clear_scr()
            choice = input('Filename: ')
            if os.path.isfile(choice):
                mac_val = get_hash(choice)
                if mac_val:
                    get_user_infor(mac_val)
                else:
                    print('Please check whether file is signed or not')
            input('\nPress any key to continue')
        elif selector == '9':
            clear_scr()
            choice = input('File to convert: ')
            if os.path.isfile(choice):
                to_original(choice)
            else:
                print('%s is not a file' %choice)
            input('\nPress any key to continue')
        elif selector == '10':
            clear_scr()
            choice = input('Are you sure (y/N)')
            if choice in ['y', 'Y']:
                sys.exit(0)
            else:
                input('\nPress any key to continue')
                clear_scr()
        else:
            clear_scr()
            input('Not in choices')

    pass


if __name__ == '__main__':
    if len(sys.argv) == 2:
        server = sys.argv[1]
        S_URL = 'http://%s/savefile' % server

    before_main()